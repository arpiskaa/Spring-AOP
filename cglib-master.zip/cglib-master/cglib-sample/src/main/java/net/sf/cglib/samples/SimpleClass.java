package net.sf.cglib.samples;

public class SimpleClass {

}
